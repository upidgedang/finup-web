# FinUp v2.3.1 — Release Readiness

## Identitas

- Application ID: `com.finup.app`
- Version Name: `2.3.1`
- Version Code: `29`
- Signing: keystore resmi FinUp yang sama dengan v2.3.0

## Pemeriksaan yang dilakukan

- Uji statis layar pembuka dan visibilitas form login.
- Uji statis submit form login melalui Enter/Done.
- Uji migrasi sesi terenkripsi.
- Uji integritas data dan pagination transaksi.
- Uji konfigurasi keamanan Android dan Firebase Rules.
- Verifikasi signature APK dan AAB.
- Pemeriksaan isi ZIP/APK/AAB dan checksum SHA-256.

## Uji perangkat yang tetap disarankan

- Buka FinUp dari Home Android ketika sesi masih aktif: harus menampilkan layar pembuka lalu langsung Dashboard tanpa form login.
- Force-stop lalu buka kembali: hasil harus sama selama sesi Firebase masih valid.
- Isi email dan kata sandi yang valid, lalu tekan Done/Enter: harus masuk sama seperti menekan tombol Masuk.
- Uji login salah, tanpa internet, logout, dan login kembali.
