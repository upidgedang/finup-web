FinUp v2.3.1 — Developer Release Package

Isi utama:
- APK signed
- AAB signed
- Source clean tanpa rahasia
- Source lengkap dengan keystore dan signing (SANGAT RAHASIA)
- Paket signing/keystore terpisah (SANGAT RAHASIA)
- Firebase Rules
- Changelog, test results, verification, dan checksums

Application ID: com.finup.app
Version Name: 2.3.1
Version Code: 29

Jangan bagikan file yang bertanda RAHASIA secara publik.
Sebelum rollout luas, lakukan uji instalasi/update di HP dan validasi AAB di Play Console.
