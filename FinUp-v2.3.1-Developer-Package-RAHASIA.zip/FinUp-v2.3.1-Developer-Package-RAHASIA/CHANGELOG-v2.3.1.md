# FinUp v2.3.1 — Login Startup Fix

Version Name: **2.3.1**  
Version Code: **29**

## Perbaikan

- Menambahkan layar pembuka netral selama Firebase memulihkan sesi pengguna.
- Form login tetap tersembunyi sampai status autentikasi pertama selesai diperiksa.
- Mencegah form login muncul sekejap ketika aplikasi dibuka kembali dari Home Android dan sesi masih aktif.
- Mengubah area login menjadi formulir HTML yang sebenarnya.
- Tombol Enter/Done pada kolom kata sandi menjalankan fungsi yang sama dengan tombol **Masuk**.
- Menambahkan perlindungan agar submit tidak dijalankan ganda saat proses login masih berjalan.

## Kompatibilitas

- Application ID tetap `com.finup.app`.
- Keystore dan sertifikat signing tetap sama dengan rilis sebelumnya.
- Struktur data, Firebase Rules, dan sinkronisasi v2.3.0 tidak diubah.
