# Verification Report — FinUp v2.3.1

## Identity

- Application ID: `com.finup.app`
- Version Name: `2.3.1`
- Version Code: `29`
- Minimum SDK: `26`
- Target SDK: `36`

## Implemented fixes

1. A neutral FinUp startup screen is shown while Firebase restores the user session.
2. The login form remains hidden until the first authentication-state result is available.
3. The password input exposes the Android keyboard **Done** action.
4. Enter/Done submits the same `submitAuth()` function as the **Masuk** button.
5. Duplicate submit is blocked while the login button is disabled.

## Signing

The APK and AAB use the same FinUp signing certificate as v2.3.0.

Certificate SHA-256:

`5db513962d43749c9a772484b72e38eaedad3bc1d18bf6d7b539c8da6fed6634`

The APK contains a verified JAR/v1 signature and APK Signature Scheme v2 signature. The AAB JAR signature verifies successfully.

## Automated verification

See `TEST-RESULTS-v2.3.1.txt` and the reports inside `release/`.

## Remaining device gates

Physical-device testing is still required for the exact Home → FinUp transition, force-stop restoration, keyboard Done behavior across keyboard apps, and installation over the currently installed production APK. The AAB should also be validated by bundletool or Play Console before public rollout.
